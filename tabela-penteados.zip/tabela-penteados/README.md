# Tabela de Preços Digital — Thayná André Penteados (cliente real)

Projeto web em produção: tabela de preços de um salão de penteados, feita para ser
compartilhada no WhatsApp e atualizada pela própria dona, sem depender de desenvolvedor.

**Em produção:** [thaynaandrepenteados.netlify.app](https://thaynaandrepenteados.netlify.app)

![Prévia da tabela](assets/preview.png)

## O problema

A cliente enviava a tabela de preços como texto corrido no WhatsApp. A cada reajuste,
refazia tudo à mão — e cálculos como economia por pacote e valor por penteado eram
feitos de cabeça (e às vezes errados).

## A solução

- **Dados separados da apresentação** — todos os preços vivem num único objeto
  `TABELA` no fim do `index.html`; economia, valor unitário e rótulos tipo
  "pague 4 · leve 5" são derivados automaticamente dos dados
- **Um arquivo, zero dependências** — HTML, CSS e JS puros; fontes subsetadas com
  fontTools e embutidas em WOFF2/base64 (funciona offline, sem Google Fonts)
- **Distribuição pensada para WhatsApp** — Open Graph com imagem de capa dedicada,
  botão de agendamento via `wa.me` com mensagem pré-preenchida, e PDF espelho (A4,
  1 página) gerado com WeasyPrint para envio direto
- **Identidade visual própria** — monograma vetorial gerado programaticamente a
  partir dos glifos da fonte (fontTools → SVG), paleta e microinterações

## Como a cliente atualiza os preços

Abre o `index.html`, muda os números no bloco `TABELA`, arrasta o arquivo no
Netlify. A página recalcula tudo.

## Stack

HTML · CSS · JavaScript (vanilla) · Netlify · Python (fontTools, WeasyPrint) para o
build de fontes e PDF
